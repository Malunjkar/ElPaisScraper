# El Pais Scraper

A Java-based Selenium project to scrape articles from El País, translate titles, analyze repeated words, and test on multiple browsers using BrowserStack.

## Features

- Scrapes 5 articles from the Opinion section
- Downloads article images
- Translates titles using MyMemory API
- Finds repeated words
- Tests across 5 browsers using BrowserStack

## Requirements

- Java 20
- Selenium WebDriver
- Gson
- Apache HttpClient 5
- BrowserStack credentials

## How to Run

1. Compile and run `ElPaisScraper.java` to scrape and analyze.
2. Run `BrowserStackTest.java` to test cross-browser compatibility.
